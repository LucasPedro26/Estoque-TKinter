import tkinter as tk
from tkinter import messagebox
import csv
from tkinter import filedialog


#Lista

Sistema_de_supermercado = [
    {"Nome": "Bolacha", "Marca": "Oreo", "Tipo": 1, "Classe": "Alimentos", "Preço": 3.50, "Codigo": 1121},
    {"Nome": "Água 250ml", "Marca": "Cristal", "Tipo": 1, "Classe": "Bebidas", "Preço": 1.50, "Codigo": 1122},
    {"Nome": "Suco 500ml", "Marca": "DellVale", "Tipo": 1, "Classe": "Bebidas", "Preço": 5.10, "Codigo": 1123},
    {"Nome": "Frauda", "Marca": "Panpers", "Tipo": 1, "Classe": "Farmacia", "Preço": 10.40, "Codigo": 1124},
    {"Nome": "Energético", "Marca": "Monster", "Tipo": 1, "Classe": "Bebidas", "Preço": 5.50, "Codigo": 1125},
]

# MENU ITENS

def listar_produtos():
    lista_text.delete(1.0, tk.END)
    for produto in Sistema_de_supermercado:
        lista_text.insert(tk.END, f"Nome: {produto['Nome']}, Marca: {produto['Marca']}, Tipo: {produto['Tipo']}, Classe: {produto['Classe']}, Preço: {produto['Preço']}, Código: {produto['Codigo']}\n")
    lista_text.insert(tk.END, "\n")
    
# Campo de preenchimento

def inserir_produto():
    if nome_entry.get() == '':return     messagebox.showerror("ERRO","O produto precisa ter um nome")
    nome = nome_entry.get()
    
    if marca_entry.get() == '':return     messagebox.showerror("ERRO","O produto precisa ter um marca")
    marca = marca_entry.get()
    
    if tipo_entry.get() == '':return     messagebox.showerror("ERRO","O produto precisa ter um tipo")
    tipo = tipo_entry.get()
    
    if classe_entry.get() == '':return     messagebox.showerror("ERRO","O produto precisa ter um classe")
    classe = classe_entry.get()
    
    if preço_entry.get() == '':return     messagebox.showerror("ERRO","O produto precisa ter um preço")
    preço = float(preço_entry.get())
    
    if codigo_entry.get() == '':return     messagebox.showerror("ERRO","O produto precisa ter um código")
    codigo = int(codigo_entry.get())
    
# Verificação de duplicação de código
    for produto in Sistema_de_supermercado:
        if codigo == produto['Codigo']:
            # POP UP
            messagebox.showerror("ERRO", "Código existente, tente outro.")
            return
        
    
    Sistema_de_supermercado.append({"Nome": nome, "Marca": marca, "Tipo": tipo, "Classe": classe, "Preço": preço, "Codigo": codigo})
    #POP UP
    messagebox.showinfo("Sucesso", "Produto inserido com sucesso!")
    
    listar_produtos()
    
def remover_produto():
    if codigo_entry.get() == '':
        messagebox.showerror("ERRO", "Por favor, insira o código do produto a ser removido")
        return

    codigo = int(codigo_entry.get())

    for produto in Sistema_de_supermercado:
        if codigo == produto['Codigo']:
            resultado= messagebox.askquestion("Remover produto","voce realmente deseja fazer isso")
            print(resultado)
            if resultado == "yes": 
                Sistema_de_supermercado.remove(produto)
                messagebox.showinfo("Sucesso", "Produto removido com sucesso!")
                listar_produtos()
            return
    
    messagebox.showerror("ERRO", "Código não encontrado")
    
# Atualização de produtos
    
def atualizar_produto():
    if codigo_entry.get() == '':
        # POP UP
        messagebox.showerror("ERRO", "Por favor, insira o código do produto a ser atualizado")
        return
    
    codigo = int(codigo_entry.get())
    
    for produto in Sistema_de_supermercado:
        if codigo == produto['Codigo']:
            if nome_entry.get() != '':
                produto['Nome'] = nome_entry.get()
            if marca_entry.get() != '':
                produto['Marca'] = marca_entry.get()
            if tipo_entry.get() != '':
                produto['Tipo'] = tipo_entry.get()
            if classe_entry.get() != '':
                produto['Classe'] = classe_entry.get()
            if preço_entry.get() != '':
                produto['Preço'] = float(preço_entry.get())
                
            # POP UP
            messagebox.showinfo("Sucesso", "Produto atualizado com sucesso!")
            listar_produtos()
            return
        
    # POP UP
    messagebox.showerror("ERRO", "Código não encontrado")

# CSV Importar

def importar_csv():
    file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
    if not file_path:
        return
    
    with open(file_path, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            try:
                row['Tipo'] = int(row['Tipo'])
                row['Preço'] = float(row['Preço'])
                row['Codigo'] = int(row['Codigo'])
                Sistema_de_supermercado.append(row)
            except ValueError:
                #POP UP
                messagebox.showerror("ERRO", "Erro ao ler o arquivo CSV. Verifique os dados e tente novamente.")
                return
        #POP UP    
        messagebox.showinfo("Sucesso", "Produtos importados com sucesso!")
        listar_produtos()

# CSV Exportar

def exportar_csv():
    file_path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
    if not file_path:
        return
    
    with open(file_path, mode='w', newline='') as csvfile:
        fieldnames = ["Nome", "Marca", "Tipo", "Classe", "Preço", "Codigo"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        writer.writeheader()
        for produto in Sistema_de_supermercado:
            writer.writerow(produto)
    #POP UP
    messagebox.showinfo("Sucesso", "Produtos exportados com sucesso!")


# Janela
LPapp = tk.Tk()
LPapp.title("Controle de Estoque")
LPapp.iconbitmap("logo.ico")
LPapp.geometry("360x800")
LPapp.resizable(width=False, height=False)
LPapp.configure(background="#24252B")

# Interface
frame = tk.Frame(LPapp,bg="#24252B")
frame.pack(padx=10, pady=10)

# Colunas

tk.Label(frame, text="Nome:",bg="#24252b",fg="#df7e31",font=("Helvetica", 13)).grid(row=0, column=0, padx=5, pady=5)
nome_entry = tk.Entry(frame,width=30)
nome_entry.grid(row=0, column=1, padx=5, pady=5)

tk.Label(frame, text="Marca:",bg="#24252b",fg="#df7e31",font=("Helvetica", 13)).grid(row=1, column=0, padx=5, pady=5)
marca_entry = tk.Entry(frame,width=30)
marca_entry.grid(row=1, column=1, padx=5, pady=5)

tk.Label(frame, text="Tipo:",bg="#24252b",fg="#df7e31",font=("Helvetica", 13)).grid(row=2, column=0, padx=5, pady=5)
tipo_entry = tk.Entry(frame,width=30)
tipo_entry.grid(row=2, column=1, padx=5, pady=5)

tk.Label(frame, text="Classe:",bg="#24252b",fg="#df7e31",font=("Helvetica", 13)).grid(row=3, column=0, padx=5, pady=5)
classe_entry = tk.Entry(frame,width=30)
classe_entry.grid(row=3, column=1, padx=5, pady=5)

tk.Label(frame, text="Preço:",bg="#24252b",fg="#df7e31",font=("Helvetica", 13)).grid(row=4, column=0, padx=5, pady=5)
preço_entry = tk.Entry(frame,width=30)
preço_entry.grid(row=4, column=1, padx=5, pady=5)

tk.Label(frame, text="Código:",bg="#24252b",fg="#df7e31",font=("Helvetica", 13)).grid(row=5, column=0, padx=5, pady=5)
codigo_entry = tk.Entry(frame,width=30)
codigo_entry.grid(row=5, column=1, padx=5, pady=5)


# BOTÕES INTERATIVOS
 
inserir_button = tk.Button(frame, text="Inserir Produto",bg="#313131",fg="#fff",font=("Helvetica", 13),width=14, command=inserir_produto)
inserir_button.grid(row=6,column=0 ,columnspan=1, padx=2, pady=10)

listar_button = tk.Button(frame, text="Atualizar",bg="#313131",fg="#fff",font=("Helvetica", 13),width=14, command=listar_produtos)
listar_button.grid(row=6,column=1 ,columnspan=1, padx=2, pady=2)

remover_button = tk.Button(frame, text="Remover",bg="#313131",fg="#fff",font=("Helvetica", 13),width=14, command=remover_produto)
remover_button.grid(row=7,column=0, columnspan=1, padx=5, pady=5)

atualizar_button = tk.Button(frame, text="Atualizar Produto",bg="#313131",fg="#fff",font=("Helvetica", 13),width=14, command=atualizar_produto)
atualizar_button.grid(row=7,column=1, columnspan=2, padx=5, pady=5)

importar_button = tk.Button(frame, text="Importar",bg="#313131",fg="#fff",font=("Helvetica", 10),width=14, command=importar_csv)
importar_button.grid(row=10, columnspan=2, padx=5, pady=5)

exportar_button = tk.Button(frame, text="Exportar",bg="#313131",fg="#fff",font=("Helvetica", 10),width=14, command=exportar_csv)
exportar_button.grid(row=11, columnspan=2, padx=5, pady=5)

lista_text = tk.Text(frame,bg="#313131",fg="#fff", width=40, height=40)
lista_text.grid(row=12, columnspan=2, padx=5, pady=5)

LPapp.mainloop()